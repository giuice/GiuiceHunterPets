# Lib: HereBeDragons

## [2.14.3-release](https://github.com/Nevcairiel/HereBeDragons/tree/2.14.3-release) (2024-07-24)
[Full Changelog](https://github.com/Nevcairiel/HereBeDragons/compare/2.14.2-release...2.14.3-release) [Previous Releases](https://github.com/Nevcairiel/HereBeDragons/releases)

- Fix classic compat, which lacks GetMapWorldSize  
    ... for reasons, why such a base API is missing  
