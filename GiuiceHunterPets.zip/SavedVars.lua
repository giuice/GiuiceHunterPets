GHP_SavedVars = GHP_SavedVars or {
    worldMapPins = 1,  -- Default to "All Pets Pins"
    tooltips = true,
    minimapPins = true,
    position = nil,
    minimap = { hide = false }
}